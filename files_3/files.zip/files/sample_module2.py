def print_function2():
    print("sample_module2.py：関数print_function2呼び出し")

var2_1 = "sample_module2.py：変数var2_1"
var2_2 = "sample_module2.py：変数var2_2"
