def print_function2():
    print("sample_module2.py：関数print_function2")

var2_1 = "sample_module2.py：var2_1"
var2_2 = "sample_module2.py：var2_2"
