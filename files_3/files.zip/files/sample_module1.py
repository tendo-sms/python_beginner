def print_function1():
    print("sample_module1.py：関数print_function1")

var1_1 = "sample_module1.py：var1_1"
var1_2 = "sample_module1.py：var1_2"
