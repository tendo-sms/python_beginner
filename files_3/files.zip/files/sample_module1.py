def print_function1():
    print("sample_module1.py：関数print_function1呼び出し")

var1_1 = "sample_module1.py：変数var1_1"
var1_2 = "sample_module1.py：変数var1_2"
