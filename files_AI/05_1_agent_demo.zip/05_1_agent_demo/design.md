# 設計書: pca.ipynb

要求仕様書 [`spec.md`](spec.md) および合否判定リスト [`acceptance.md`](acceptance.md) に基づく
`pca.ipynb`（PCA 再現 Notebook）の設計を示す。

---

## 1. 設計方針

- 論文 (Sci. Rep. 2024, 14:18285) の PCA 結果のうち **Fig 3A（茶種 PCA）** と
  **Fig 3C（ミネラル PCA）** を、`data.csv` と Python (scikit-learn) で再現する。
- 解析は 2 系統。両者とも「**標準化 → PCA → バイプロット**」の同一パイプラインだが、
  入力行列の向きが異なる（茶種 PCA はそのまま、ミネラル PCA は転置）。
- 共通処理は関数化して重複を避け、再現性（決定性）と可読性を担保する。
- Notebook は **上から順に Restart & Run All で完走** することを前提に設計する（A-1）。

---

## 2. 全体構成（セル構成）

Notebook は以下のセル列で構成する。各コードセルの直前に対応する Markdown 解説セルを置く（D-2）。

| # | 種別 | 内容 | 対応要件 |
|---|------|------|----------|
| 0 | MD | タイトル・目的・論文との対応・スコープ（PCA のみ） | — |
| 1 | MD | ライブラリと前提の説明 | — |
| 2 | Code | import（pandas, numpy, sklearn, matplotlib）+ 定数定義 | A-4, FR-4 |
| 3 | MD | FR-1 データ読込と検証の説明 | — |
| 4 | Code | `data.csv` 読込・行数/列検証・欠損チェック | FR-1, A-2, A-3 |
| 5 | MD | FR-2 茶種 PCA 手法説明（標準化→PCA、論文 Fig 3A 対応） | D-2 |
| 6 | Code | 茶種 PCA 実行（標準化・PCA・寄与率 print） | FR-2, B-1〜B-3 |
| 7 | Code | 茶種 PCA バイプロット描画 | B-4〜B-7 |
| 8 | MD | FR-3 ミネラル PCA 手法説明（転置→標準化→PCA、Fig 3C 対応） | D-2 |
| 9 | Code | ミネラル PCA 実行（転置・標準化・PCA・寄与率 print） | FR-3, C-1〜C-3 |
| 10 | Code | ミネラル PCA スコアプロット描画 | C-4〜C-6 |
| 11 | MD | 結果まとめ（寄与率の論文値との対比表）・許容事項の明記 | D-3 |

---

## 3. モジュール／関数設計

共通処理を関数化し、2 系統の解析から再利用する。

### 3.1 定数（セル 2）

```python
MINERALS = ["Al", "Ca", "Cu", "Fe", "K", "Mg", "Mn", "Na", "Zn"]  # 解析対象 9 列
TEA_COL  = "tea"          # 色分けキー (BT/BC/GT/GC)
CSV_PATH = "data.csv"
RANDOM_STATE = 0          # 念のため固定（FR-4 / D-1）
TEA_COLORS = {"BT": ..., "BC": ..., "GT": ..., "GC": ...}  # 茶種→色の対応
```

### 3.2 関数一覧

| 関数 | 役割 | 入出力 |
|------|------|--------|
| `load_data(path) -> pd.DataFrame` | CSV 読込・168 行検証・9 列存在検証・欠損/非数値検証 | path → DataFrame（検証 NG は `assert`/例外で明示） |
| `run_pca(X) -> (PCA, scores, evr)` | `StandardScaler` で標準化 → `PCA(random_state)` 実行 | 数値行列 X → 学習済 PCA・スコア・寄与率配列 |
| `biplot_scores(scores, evr, labels, colors, title)` | スコア散布図（色分け）+ loading 矢印を重畳 | 図を描画 |
| `plot_points(scores, evr, point_labels, title)` | 点+テキストラベルの散布図（ミネラル PCA 用） | 図を描画 |

`run_pca` を 2 系統で共有することで B-1/B-2 と C-2 の処理を一元化する。
標準化は scikit-learn の `StandardScaler`（平均0・分散1）を使用する（B-1, C-2）。

---

## 4. 解析 A: 茶種 PCA（Fig 3A 相当）

### 4.1 データフロー

```
df[MINERALS]            # (168 × 9) サンプル×ミネラル
  → StandardScaler      # 列(ミネラル)ごとに標準化       … B-1
  → PCA                 # 主成分分解                      … B-2
  → scores (168 × k), explained_variance_ratio_
```

### 4.2 出力

- **寄与率**: PC1, PC2 個別とその累積を `print`。`PC1+PC2 ≈ 85.65%`（86.0% ± 1.0% に収まる）… B-3, D-3。
- **バイプロット**（セル 7）… B-4〜B-7:
  - スコア散布図を `df["tea"]`（BT/BC/GT/GC）で色分け、凡例付き。
  - 9 ミネラルの loading ベクトル（`components_` を矢印で重畳）。loading はスコアの
    スケールに合わせて適宜スケーリングし、矢印先にミネラル名を表示。
  - 軸ラベルに寄与率%（例 `PC1 (xx.x%)`）、タイトル、凡例を付与（B-7）。
  - 期待される所見: **BC と GC が PC1 方向に分離**、**BT/GT は重なる**（B-6）。

---

## 5. 解析 C: ミネラル PCA（Fig 3C 相当）

### 5.1 データフロー

```
df[MINERALS].T          # 転置 → (9 × 168) ミネラル×サンプル   … C-1
  → StandardScaler      # 標準化                               … C-2
  → PCA
  → scores (9 × k), explained_variance_ratio_
```

転置により「観測対象＝9 ミネラル / 特徴量＝168 サンプル」となる。
これが §2 検証表で 99.97% を再現する確定方式（spec §8）。

### 5.2 出力

- **寄与率**: `PC1+PC2 ≈ 99.97%`（99.97% ± 0.05%）を `print`… C-3, D-3。
- **スコアプロット**（セル 10）… C-4〜C-6:
  - 9 ミネラルを PC1-PC2 平面に点で配置し、各点に **ミネラル名ラベル**を付与。
  - 軸ラベルに寄与率%、タイトルを付与（C-6）。
  - 期待される所見: **Zn, Al, Mn, Na, Fe, Cu が近接**、**K・Mg・Ca が離れて位置**（C-5）。

---

## 6. データ検証設計（FR-1）

`load_data` で以下を検証し、NG 時は明示的に例外/メッセージを出す:

1. ファイル読込（先頭に BOM があるため `encoding="utf-8-sig"` を考慮）。
2. 行数 == 168（A-2）。
3. 9 ミネラル列がすべて存在（A-3）。
4. ミネラル列が数値型で欠損なし（`isna().any()` / 数値変換可否）。欠損・非数値はエラー報告（spec §3）。

---

## 7. 再現性・品質（D 項）

- PCA は決定的だが `random_state=RANDOM_STATE` を明示し、再実行で同値（D-1）。
- 乱数依存処理は持たない。
- 寄与率は `print` で明示出力（D-3）。
- 各処理ブロック直前に Markdown で手法と論文 Figure との対応を記述（D-2）。

---

## 8. 許容事項（設計上の留意点 / acceptance §E）

- **PC 軸の符号反転**は許容。所見の読み取り（分離/近接の関係）が成立すればよい。
  必要なら可読性のため符号を揃える後処理を入れてもよいが必須ではない。
- 配色・マーカー・凡例位置などの装飾差は許容。
- 茶種 PCA 寄与率は 85〜87% の範囲で合格（目標 86.0%、実測 85.65%）。

---

## 9. 依存ライブラリ（非機能 / A-4）

`pandas`, `numpy`, `scikit-learn`, `matplotlib` のみ。Python 3.10+。
`seaborn` は任意（未使用でも可）。外部ネットワーク不要、`data.csv` 同梱で動作。

---

## 10. 要件トレーサビリティ

| 要件 | 実装箇所（セル/関数） |
|------|----------------------|
| FR-1 / A-2,A-3 | セル4 `load_data` |
| A-4 | セル2 import |
| FR-2 / B-1〜B-3 | セル6 `run_pca` |
| B-4〜B-7 | セル7 `biplot_scores` |
| FR-3 / C-1〜C-3 | セル9（転置 + `run_pca`） |
| C-4〜C-6 | セル10 `plot_points` |
| FR-4 / D-1〜D-3 | セル2 定数、各 MD セル、寄与率 print |
